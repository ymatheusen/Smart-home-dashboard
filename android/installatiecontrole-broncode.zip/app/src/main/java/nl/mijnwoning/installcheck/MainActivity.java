package nl.mijnwoning.installcheck;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.Intent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.security.MessageDigest;
import java.util.Locale;

/** Local installation diagnosis. No network, credentials or access to dashboard data. */
public class MainActivity extends Activity {
    private static final String APP = "nl.mijnwoning.dashboard";
    private static final String EXPECTED = "f9f4e31e125e5e438d86dbdaf09df088dc4c943bc3396a77d9855cf6e4de9918";
    private String report;
    private File apk;
    private boolean canUpdate;
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private int flags() { return Build.VERSION.SDK_INT >= 28 ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES; }
    private String certificate(PackageInfo info) throws Exception {
        Signature[] signatures = Build.VERSION.SDK_INT >= 28 ? (info.signingInfo == null ? null : info.signingInfo.getApkContentsSigners()) : info.signatures;
        if (signatures == null || signatures.length == 0) return "niet beschikbaar";
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(signatures[0].toByteArray());
        StringBuilder out = new StringBuilder();
        for (byte b : digest) out.append(String.format(Locale.ROOT, "%02x", b & 255));
        return out.toString();
    }
    private long version(PackageInfo info) { return Build.VERSION.SDK_INT >= 28 ? info.getLongVersionCode() : info.versionCode; }
    private TextView text(String value, int size, int color) {
        TextView view = new TextView(this);
        view.setText(value); view.setTextSize(size); view.setTextColor(color);
        view.setPadding(0, dp(8), 0, dp(8));
        return view;
    }
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int gold = Color.rgb(233,197,129), white = Color.rgb(242,235,220);
        StringBuilder details = new StringBuilder();
        details.append("Telefoon: ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL)
            .append("\nAndroid: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        String conclusion = "Controle niet afgerond";
        try {
            File dir = new File(getCacheDir(), "install");
            if (!dir.isDirectory() && !dir.mkdirs()) throw new IllegalStateException("Tijdelijke map niet beschikbaar");
            apk = new File(dir, "Mijn-Woning-0.5.2.apk");
            try (InputStream in = getAssets().open("update.apk"); FileOutputStream out = new FileOutputStream(apk)) {
                byte[] buffer = new byte[32768]; int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            }
            PackageInfo archive = getPackageManager().getPackageArchiveInfo(apk.getAbsolutePath(), flags());
            boolean valid = archive != null && APP.equals(archive.packageName) && EXPECTED.equals(certificate(archive));
            details.append("APK 0.5.2 lokaal leesbaar en ondertekening geldig: ").append(valid ? "JA" : "NEE").append("\n");
            try {
                PackageInfo installed = getPackageManager().getPackageInfo(APP, flags());
                String actual = certificate(installed);
                boolean same = EXPECTED.equals(actual);
                details.append("Geïnstalleerd: ").append(installed.versionName).append(" (code ").append(version(installed)).append(")\n")
                    .append("Zelfde ondertekening: ").append(same ? "JA" : "NEE").append("\n\n")
                    .append("Certificaat bestaande app:\n").append(actual).append("\n");
                canUpdate = valid && same && version(installed) <= version(archive);
                if (!same) conclusion = "De bestaande app gebruikt een andere sleutel. De nieuwe APK kan die app niet bijwerken.";
                else if (!valid) conclusion = "Android kan het meegeleverde pakket niet volledig lezen. Kopieer het resultaat hieronder.";
                else if (version(installed) > version(archive)) conclusion = "Er is al een nieuwere versie geïnstalleerd.";
                else if (version(installed) == version(archive)) conclusion = "Versie 0.5.2 is al geïnstalleerd. Je kunt de app openen of de installatie opnieuw proberen.";
                else conclusion = "De APK en de bestaande app passen bij elkaar. Probeer de update via de knop hieronder.";
            } catch (PackageManager.NameNotFoundException absent) {
                details.append("Geïnstalleerde Android-app: niet gevonden\n");
                canUpdate = valid;
                conclusion = valid ? "De Android-app is niet gevonden. Een browser-PWA is een andere installatie. Je kunt de APK hieronder installeren." : "Android kan de APK niet volledig lezen.";
            }
        } catch (Exception e) { details.append("Controlefout: ").append(e.getClass().getSimpleName()).append("\n"); }
        report = conclusion + "\n\n" + details;
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true); scroll.setBackgroundColor(Color.rgb(21,20,19));
        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(24),dp(24),dp(24),dp(32));
        scroll.addView(content);
        content.addView(text("MIJN WONING · INSTALLATIECONTROLE", 11, gold));
        content.addView(text("Waarom lukt de update niet?", 26, white));
        content.addView(text(conclusion, 17, gold));
        TextView diagnostics = text(details.toString(), 14, white); diagnostics.setTextIsSelectable(true); content.addView(diagnostics);
        if (canUpdate) {
            Button install = new Button(this); install.setText("Probeer installatie van 0.5.2");
            install.setOnClickListener(v -> installUpdate()); content.addView(install);
        }
        Button copy = new Button(this); copy.setText("Resultaat kopiëren");
        copy.setOnClickListener(v -> { ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Installatiecontrole", report)); Toast.makeText(this,"Resultaat gekopieerd",Toast.LENGTH_SHORT).show(); });
        content.addView(copy);
        Button open = new Button(this); open.setText("Bestaande Mijn Woning openen");
        open.setOnClickListener(v -> { Intent intent = getPackageManager().getLaunchIntentForPackage(APP); if (intent != null) startActivity(intent); else Toast.makeText(this,"Android-app niet gevonden",Toast.LENGTH_SHORT).show(); });
        content.addView(open);
        content.addView(text("Deze controle gebruikt geen internet en leest geen Hue- of Shelly-koppelingen. Deel het resultaat met Codex. Je kunt deze controle-app daarna verwijderen.", 13, Color.rgb(173,164,146)));
        setContentView(scroll);
    }
    private void installUpdate() {
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
            Toast.makeText(this,"Sta installatie door deze controle-app toe en tik daarna opnieuw op de installatieknop.",Toast.LENGTH_LONG).show();
            return;
        }
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", apk);
        Intent intent = new Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.setClipData(ClipData.newRawUri("Mijn Woning 0.5.2", uri));
        try { startActivity(intent); }
        catch (Exception e) { Toast.makeText(this,"Installer kon niet worden geopend: " + e.getClass().getSimpleName(),Toast.LENGTH_LONG).show(); }
    }
}
