# Mijn Woning installatiecontrole

Losse controle-app met pakketnaam nl.mijnwoning.installcheck. De app gebruikt geen internet en heeft geen toegang tot de opgeslagen Hue- of Shelly-instellingen van Mijn Woning. Hij leest via Android de versie en publieke ondertekening van nl.mijnwoning.dashboard en controleert lokaal een meegeleverde, ongewijzigde APK van 0.5.2. Het resultaat kan de gebruiker naar het klembord kopiëren.

Alleen na een druk op de installatieknop wordt die APK aan de gewone Android-installer aangeboden, via een beperkte FileProvider voor de tijdelijke install-map. Android vraagt daarvoor zo nodig de standaard toestemming voor installeren vanuit deze bron. De bestaande app wordt niet automatisch gewijzigd of verwijderd. Er is geen sleutel-, wachtwoord- of apparaatconfiguratie in deze broncode of de APK opgenomen.

Deze broncode is voor controle en herbouw met Gradle 8.11.1, Android Gradle Plugin 8.7.2 en SDK 35. Voor de releasebuild moeten MW_ANDROID_STORE_FILE, MW_ANDROID_STORE_PASSWORD en MW_ANDROID_STORE_ALIAS in de lokale bouwomgeving worden ingesteld. De meegeleverde update.apk is exact de al gepubliceerde 0.5.2-APK.
