#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
echo 'Mijn Woning 0.5.2 installeren via USB'
echo 'De bestaande app wordt bijgewerkt. Er wordt geen app verwijderd.'
case "$(uname -s)" in
  Darwin) platform=darwin; actual=$(shasum -a 256 Mijn-Woning-0.5.2.apk | cut -d ' ' -f 1) ;;
  Linux) platform=linux; actual=$(sha256sum Mijn-Woning-0.5.2.apk | cut -d ' ' -f 1) ;;
  *) echo 'Gebruik op Windows Installeren-Windows.bat'; exit 1 ;;
esac
if [ "$actual" != '5b36c849d8639f621c45b3f37810bdf765ef51c5073270aa3e6eaa077b4f0cb3' ]; then
  echo 'De APK-bestandscontrole is mislukt.'; exit 1
fi
if [ ! -x platform-tools/adb ]; then
  echo 'Officiële Android-tools van Google downloaden...'
  curl -fL --retry 2 "https://dl.google.com/android/repository/platform-tools-latest-${platform}.zip" -o platform-tools.zip
  unzip -q -o platform-tools.zip
fi
adb="$PWD/platform-tools/adb"
trap '"$adb" -P 5039 kill-server >/dev/null 2>&1 || true' EXIT
"$adb" -P 5039 start-server
echo 'Verbind de telefoon via USB, zet USB-debugging aan en bevestig de computer op de telefoon.'
echo 'Zie LEESMIJ.txt voor de stappen op Xiaomi.'
read -r -p 'Druk op Enter wanneer de telefoon verbonden is. '
if ! "$adb" -P 5039 -d get-state; then
  echo 'De telefoon is nog niet via USB-debugging bereikbaar. Controleer de kabel en de toestemmingsvraag.'
  read -r -p 'Druk op Enter om te sluiten. '; exit 1
fi
log="$PWD/installatie-resultaat.txt"
{
  echo 'Mijn Woning installatiecontrole'
  echo 'Telefoonmodel:'; "$adb" -P 5039 -d shell getprop ro.product.model
  echo 'Android-versie:'; "$adb" -P 5039 -d shell getprop ro.build.version.release
  echo 'Android API:'; "$adb" -P 5039 -d shell getprop ro.build.version.sdk
} > "$log" 2>&1
echo 'Installeren... Kijk ook op de telefoon voor een eventuele bevestiging.'
set +e
"$adb" -P 5039 -d install -r --no-streaming "$PWD/Mijn-Woning-0.5.2.apk" 2>&1 | tee -a "$log"
result=${PIPESTATUS[0]}
set -e
echo 'Bij Success is de update geïnstalleerd. Open dan Mijn Woning op de telefoon.'
echo 'Bij een fout: stuur installatie-resultaat.txt terug in de chat.'
read -r -p 'Druk op Enter om te sluiten. '
exit "$result"
