@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
echo Mijn Woning 0.5.2 installeren via USB
echo De bestaande app wordt bijgewerkt. Er wordt geen app verwijderd.
echo.
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; if ((Get-FileHash -LiteralPath 'Mijn-Woning-0.5.2.apk' -Algorithm SHA256).Hash -ne '5b36c849d8639f621c45b3f37810bdf765ef51c5073270aa3e6eaa077b4f0cb3') { throw 'De APK-bestandscontrole is mislukt.' }"
if errorlevel 1 goto failed
if exist "platform-tools\adb.exe" goto toolsready
echo Officiele Android-tools van Google downloaden...
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -UseBasicParsing -Uri 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip' -OutFile 'platform-tools.zip'; Expand-Archive -LiteralPath 'platform-tools.zip' -DestinationPath '.' -Force"
if errorlevel 1 goto failed
:toolsready
set "MW_ADB=platform-tools\adb.exe"
"%MW_ADB%" -P 5039 start-server
if errorlevel 1 goto failed
echo.
echo Verbind de telefoon via USB en zet USB-debugging aan in Ontwikkelaarsopties.
echo Ontgrendel de telefoon en bevestig de vraag om deze computer toe te staan.
echo Zie LEESMIJ.txt voor de stappen op Xiaomi.
pause
"%MW_ADB%" -P 5039 -d get-state
if errorlevel 1 goto nodevice
echo Mijn Woning installatiecontrole > "installatie-resultaat.txt"
echo Telefoonmodel: >> "installatie-resultaat.txt"
"%MW_ADB%" -P 5039 -d shell getprop ro.product.model >> "installatie-resultaat.txt" 2>&1
echo Android-versie: >> "installatie-resultaat.txt"
"%MW_ADB%" -P 5039 -d shell getprop ro.build.version.release >> "installatie-resultaat.txt" 2>&1
echo Android API: >> "installatie-resultaat.txt"
"%MW_ADB%" -P 5039 -d shell getprop ro.build.version.sdk >> "installatie-resultaat.txt" 2>&1
echo.
echo Installeren... Kijk ook op de telefoon voor een eventuele bevestiging.
"%MW_ADB%" -P 5039 -d install -r --no-streaming "Mijn-Woning-0.5.2.apk" >> "installatie-resultaat.txt" 2>&1
echo.
type "installatie-resultaat.txt"
echo.
echo Bij Success is de update geinstalleerd. Open dan Mijn Woning op de telefoon.
echo Bij een fout: stuur installatie-resultaat.txt terug in de chat.
"%MW_ADB%" -P 5039 kill-server >nul 2>&1
pause
exit /b
:nodevice
echo.
echo De telefoon is nog niet via USB-debugging bereikbaar.
echo Controleer de USB-kabel en de toestemmingsvraag op de telefoon.
echo Maak een foto van deze melding als het niet lukt.
if exist "platform-tools\adb.exe" "platform-tools\adb.exe" -P 5039 kill-server >nul 2>&1
pause
exit /b 1
:failed
echo.
echo Voorbereiden is niet gelukt. Maak een foto van de fout hierboven.
if exist "platform-tools\adb.exe" "platform-tools\adb.exe" -P 5039 kill-server >nul 2>&1
pause
exit /b 1
